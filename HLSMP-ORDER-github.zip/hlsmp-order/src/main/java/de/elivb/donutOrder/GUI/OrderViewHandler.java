package de.elivb.donutOrder.GUI;

import de.elivb.donutOrder.Order;
import de.elivb.donutOrder.Manager.OrderItem;
import de.elivb.donutOrder.Manager.OrderManager;
import de.elivb.donutOrder.utils.ColorUtil;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.UUID;
import java.util.stream.Collectors;
import org.bukkit.Bukkit;
import org.bukkit.Material;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.event.player.AsyncPlayerChatEvent;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.InventoryHolder;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;

public class OrderViewHandler implements Listener {
   private final Order plugin;
   private final OrderManager orderManager;
   private final OrderGUI orderGUI;
   private final Map<UUID, String> orderViewSortMode;
   private final Map<UUID, String> orderViewFilterMode;
   private final Map<UUID, String> orderViewSearchQuery;
   private final Map<UUID, Boolean> orderViewSearchMode;
   private final Set<UUID> orderViewIgnoreCloseEvents;
   private final Map<UUID, Integer> orderViewCurrentPage;
   private final Set<Material> BLOCK_MATERIALS;
   private final Set<Material> TOOL_MATERIALS;
   private final Set<Material> FOOD_MATERIALS;
   private final Set<Material> COMBAT_MATERIALS;
   private final Set<Material> POTION_MATERIALS;
   private final Set<Material> BOOK_MATERIALS;
   private final Set<Material> INGREDIENT_MATERIALS;
   private final Set<Material> UTILITY_MATERIALS;

   public OrderViewHandler(Order plugin, OrderManager orderManager, OrderGUI orderGUI) {
      this.BLOCK_MATERIALS = new HashSet(Arrays.asList(Material.STONE, Material.GRANITE, Material.DIORITE, Material.ANDESITE, Material.COBBLESTONE, Material.BEDROCK, Material.SAND, Material.GRAVEL, Material.DIRT, Material.GRASS_BLOCK, Material.OAK_LOG, Material.SPRUCE_LOG, Material.BIRCH_LOG, Material.JUNGLE_LOG, Material.ACACIA_LOG, Material.DARK_OAK_LOG, Material.OAK_PLANKS, Material.SPRUCE_PLANKS, Material.BIRCH_PLANKS, Material.JUNGLE_PLANKS, Material.ACACIA_PLANKS, Material.DARK_OAK_PLANKS, Material.OAK_LEAVES, Material.SPRUCE_LEAVES, Material.BIRCH_LEAVES, Material.JUNGLE_LEAVES, Material.ACACIA_LEAVES, Material.DARK_OAK_LEAVES));
      this.TOOL_MATERIALS = new HashSet(Arrays.asList(Material.WOODEN_PICKAXE, Material.STONE_PICKAXE, Material.IRON_PICKAXE, Material.GOLDEN_PICKAXE, Material.DIAMOND_PICKAXE, Material.NETHERITE_PICKAXE, Material.WOODEN_AXE, Material.STONE_AXE, Material.IRON_AXE, Material.GOLDEN_AXE, Material.DIAMOND_AXE, Material.NETHERITE_AXE, Material.WOODEN_SHOVEL, Material.STONE_SHOVEL, Material.IRON_SHOVEL, Material.GOLDEN_SHOVEL, Material.DIAMOND_SHOVEL, Material.NETHERITE_SHOVEL, Material.WOODEN_HOE, Material.STONE_HOE, Material.IRON_HOE, Material.GOLDEN_HOE, Material.DIAMOND_HOE, Material.NETHERITE_HOE, Material.FISHING_ROD, Material.SHEARS, Material.FLINT_AND_STEEL, Material.COMPASS, Material.CLOCK, Material.LEAD, Material.NAME_TAG));
      this.FOOD_MATERIALS = new HashSet(Arrays.asList(Material.APPLE, Material.GOLDEN_APPLE, Material.ENCHANTED_GOLDEN_APPLE, Material.BREAD, Material.PORKCHOP, Material.COOKED_PORKCHOP, Material.BEEF, Material.COOKED_BEEF, Material.CHICKEN, Material.COOKED_CHICKEN, Material.RABBIT, Material.COOKED_RABBIT, Material.MUTTON, Material.COOKED_MUTTON, Material.COD, Material.COOKED_COD, Material.SALMON, Material.COOKED_SALMON, Material.TROPICAL_FISH, Material.PUFFERFISH, Material.CAKE, Material.COOKIE, Material.MELON_SLICE, Material.PUMPKIN_PIE, Material.CARROT, Material.POTATO, Material.BAKED_POTATO, Material.BEETROOT, Material.BEETROOT_SOUP, Material.MUSHROOM_STEW, Material.RABBIT_STEW, Material.SUSPICIOUS_STEW, Material.HONEY_BOTTLE));
      this.COMBAT_MATERIALS = new HashSet(Arrays.asList(Material.WOODEN_SWORD, Material.STONE_SWORD, Material.IRON_SWORD, Material.GOLDEN_SWORD, Material.DIAMOND_SWORD, Material.NETHERITE_SWORD, Material.BOW, Material.CROSSBOW, Material.TRIDENT, Material.SHIELD, Material.LEATHER_HELMET, Material.LEATHER_CHESTPLATE, Material.LEATHER_LEGGINGS, Material.LEATHER_BOOTS, Material.CHAINMAIL_HELMET, Material.CHAINMAIL_CHESTPLATE, Material.CHAINMAIL_LEGGINGS, Material.CHAINMAIL_BOOTS, Material.IRON_HELMET, Material.IRON_CHESTPLATE, Material.IRON_LEGGINGS, Material.IRON_BOOTS, Material.GOLDEN_HELMET, Material.GOLDEN_CHESTPLATE, Material.GOLDEN_LEGGINGS, Material.GOLDEN_BOOTS, Material.DIAMOND_HELMET, Material.DIAMOND_CHESTPLATE, Material.DIAMOND_LEGGINGS, Material.DIAMOND_BOOTS, Material.NETHERITE_HELMET, Material.NETHERITE_CHESTPLATE, Material.NETHERITE_LEGGINGS, Material.NETHERITE_BOOTS, Material.TOTEM_OF_UNDYING, Material.ENDER_PEARL, Material.ENDER_EYE));
      this.POTION_MATERIALS = new HashSet(Arrays.asList(Material.POTION, Material.SPLASH_POTION, Material.LINGERING_POTION, Material.GLASS_BOTTLE, Material.BREWING_STAND));
      this.BOOK_MATERIALS = new HashSet(Arrays.asList(Material.BOOK, Material.WRITABLE_BOOK, Material.WRITTEN_BOOK, Material.ENCHANTED_BOOK, Material.KNOWLEDGE_BOOK));
      this.INGREDIENT_MATERIALS = new HashSet(Arrays.asList(Material.COAL, Material.CHARCOAL, Material.RAW_IRON, Material.RAW_COPPER, Material.RAW_GOLD, Material.IRON_INGOT, Material.COPPER_INGOT, Material.GOLD_INGOT, Material.NETHERITE_INGOT, Material.DIAMOND, Material.EMERALD, Material.LAPIS_LAZULI, Material.REDSTONE, Material.QUARTZ, Material.AMETHYST_SHARD, Material.PRISMARINE_SHARD, Material.PRISMARINE_CRYSTALS, Material.LEATHER, Material.FEATHER, Material.FLINT, Material.GUNPOWDER, Material.STRING, Material.SLIME_BALL, Material.CLAY_BALL, Material.BRICK, Material.NETHER_BRICK, Material.PAPER, Material.SUGAR, Material.STICK, Material.BLAZE_ROD, Material.BLAZE_POWDER, Material.GHAST_TEAR, Material.MAGMA_CREAM, Material.ENDER_PEARL, Material.SHULKER_SHELL, Material.POPPED_CHORUS_FRUIT, Material.PHANTOM_MEMBRANE));
      this.UTILITY_MATERIALS = new HashSet(Arrays.asList(Material.CHEST, Material.TRAPPED_CHEST, Material.BARREL, Material.SHULKER_BOX, Material.FURNACE, Material.BLAST_FURNACE, Material.SMOKER, Material.CRAFTING_TABLE, Material.ANVIL, Material.GRINDSTONE, Material.ENCHANTING_TABLE, Material.CAULDRON, Material.BEACON, Material.CONDUIT, Material.END_CRYSTAL, Material.RESPAWN_ANCHOR, Material.HOPPER, Material.DISPENSER, Material.DROPPER, Material.OBSERVER, Material.PISTON, Material.RAIL, Material.POWERED_RAIL, Material.DETECTOR_RAIL, Material.MINECART, Material.CHEST_MINECART, Material.FURNACE_MINECART, Material.TNT_MINECART, Material.HOPPER_MINECART));
      this.plugin = plugin;
      this.orderManager = orderManager;
      this.orderGUI = orderGUI;
      this.orderViewSortMode = new HashMap();
      this.orderViewFilterMode = new HashMap();
      this.orderViewSearchQuery = new HashMap();
      this.orderViewSearchMode = new HashMap();
      this.orderViewIgnoreCloseEvents = new HashSet();
      this.orderViewCurrentPage = new HashMap();
      plugin.getServer().getPluginManager().registerEvents(this, plugin);
   }

   public void openOrderGUI(Player player, int page, String search) {
      UUID playerId = player.getUniqueId();
      if (!this.orderViewSortMode.containsKey(playerId)) {
         this.orderViewSortMode.put(playerId, "most_recent");
      }

      if (!this.orderViewFilterMode.containsKey(playerId)) {
         this.orderViewFilterMode.put(playerId, "all");
      }

      this.orderViewCurrentPage.put(playerId, page);
      if (search != null) {
         this.orderViewSearchQuery.put(playerId, search);
      }

      String title = this.orderManager.getOrderViewTitle(page);
      title = ColorUtil.color(title);
      int rows = this.orderManager.getOrderViewRows();
      Inventory gui = Bukkit.createInventory((InventoryHolder)null, rows * 9, title);
      this.addOrderViewItems(gui, player, page, search);
      this.orderViewIgnoreCloseEvents.add(playerId);
      player.openInventory(gui);
      if (this.plugin.isFolia()) {
         player.getScheduler().runDelayed(this.plugin, (task) -> this.orderViewIgnoreCloseEvents.remove(playerId), (Runnable)null, 5L);
      } else {
         Bukkit.getScheduler().runTaskLater(this.plugin, () -> this.orderViewIgnoreCloseEvents.remove(playerId), 5L);
      }

   }

   private void addOrderViewItems(Inventory gui, Player player, int currentPage, String search) {
      Map<String, Object> configItems = this.orderManager.getOrderViewItems();
      UUID playerId = player.getUniqueId();
      List<OrderItem> allOrders = this.orderManager.getOrderItems();
      List<OrderItem> activeOrders = (List)allOrders.stream().filter((orderx) -> {
         if (!orderx.isActive()) {
            return false;
         } else {
            return orderx.isExpired() ? false : orderx.getRemainingAmount() > 0;
         }
      }).collect(Collectors.toList());
      List<OrderItem> filteredOrders = activeOrders;
      if (search != null && !search.isEmpty()) {
         String searchLower = search.toLowerCase();
         filteredOrders = (List)activeOrders.stream().filter((orderx) -> orderx.getName().toLowerCase().contains(searchLower) || orderx.getMaterial().name().toLowerCase().contains(searchLower) || orderx.isSpecialItem() && orderx.getSubType() != null && orderx.getSubType().toLowerCase().contains(searchLower)).collect(Collectors.toList());
      }

      String currentFilter = (String)this.orderViewFilterMode.get(playerId);
      if (currentFilter != null && !currentFilter.equals("all")) {
         filteredOrders = (List)filteredOrders.stream().filter((orderx) -> this.passesFilter(orderx, currentFilter)).collect(Collectors.toList());
      }

      String currentSort = (String)this.orderViewSortMode.get(playerId);
      if (currentSort != null) {
         switch (currentSort) {
            case "most_money" -> filteredOrders.sort((a, b) -> Double.compare(b.getPricePerItem() * (double)b.getRequestedAmount(), a.getPricePerItem() * (double)a.getRequestedAmount()));
            case "most_delivered" -> filteredOrders.sort((a, b) -> Integer.compare(b.getDeliveredAmount(), a.getDeliveredAmount()));
            case "most_recent" -> filteredOrders.sort((a, b) -> b.getCreationDate().compareTo(a.getCreationDate()));
            case "most_paid_per_item" -> filteredOrders.sort((a, b) -> Double.compare(b.getPricePerItem(), a.getPricePerItem()));
            default -> filteredOrders.sort((a, b) -> a.getName().compareToIgnoreCase(b.getName()));
         }
      }

      int itemsPerPage = 45;
      int totalPages = (int)Math.ceil((double)filteredOrders.size() / (double)itemsPerPage);
      if (totalPages == 0) {
         totalPages = 1;
      }

      currentPage = Math.max(1, Math.min(currentPage, totalPages));
      this.orderViewCurrentPage.put(playerId, currentPage);
      int startIndex = (currentPage - 1) * itemsPerPage;
      int endIndex = Math.min(startIndex + itemsPerPage, filteredOrders.size());
      List<OrderItem> pageOrders = filteredOrders.subList(startIndex, endIndex);
      this.addOrderViewNavigationItems(gui, player, currentPage, totalPages);
      Map<String, Object> sourceItemConfig = this.orderManager.getSourceItemConfig();

      for(int i = 0; i < pageOrders.size() && i < 45; ++i) {
         OrderItem order = (OrderItem)pageOrders.get(i);
         ItemStack orderItem = order.toItemStack(this.orderManager, sourceItemConfig);
         if (orderItem != null) {
            gui.setItem(i, orderItem);
         }
      }

      for(int ix = pageOrders.size(); ix < 45; ++ix) {
         gui.setItem(ix, new ItemStack(Material.AIR));
      }

   }

   private void addOrderViewNavigationItems(Inventory gui, Player player, int currentPage, int totalPages) {
      Map<String, Object> items = this.orderManager.getOrderViewItems();
      UUID playerId = player.getUniqueId();
      if (items.containsKey("previous-page")) {
         int prevSlot = this.getIntFromObject(items.get("previous-page-slot"), 45);
         Map<?, ?> prevConfig = (Map)items.get("previous-page");
         if (prevConfig != null) {
            ItemStack prevItem = this.createNavigationItem(prevConfig, "&#00fc88ᴘʀᴇᴠɪᴏᴜꜱ");
            ItemMeta meta = prevItem.getItemMeta();
            if (meta != null) {
               List<String> lore = meta.getLore();
               if (lore == null) {
                  lore = new ArrayList();
               }

               if (currentPage <= 1) {
               }

               meta.setLore(lore);
               prevItem.setItemMeta(meta);
            }

            gui.setItem(prevSlot, prevItem);
         }
      }

      if (items.containsKey("next-page")) {
         int nextSlot = this.getIntFromObject(items.get("next-page-slot"), 53);
         Map<?, ?> nextConfig = (Map)items.get("next-page");
         if (nextConfig != null) {
            ItemStack nextItem = this.createNavigationItem(nextConfig, "&#00fc88ɴᴇxᴛ");
            ItemMeta meta = nextItem.getItemMeta();
            if (meta != null) {
               List<String> lorex = meta.getLore();
               if (lorex == null) {
                  lorex = new ArrayList();
               }

               if (currentPage >= totalPages) {
               }

               meta.setLore(lorex);
               nextItem.setItemMeta(meta);
            }

            gui.setItem(nextSlot, nextItem);
         }
      }

      if (items.containsKey("refresh")) {
         Map<?, ?> refreshConfig = (Map)items.get("refresh");
         if (refreshConfig != null) {
            int refreshSlot = this.getIntFromObject(refreshConfig.get("slot"), 49);
            ItemStack refreshItem = this.createNavigationItem(refreshConfig, "Refresh");
            gui.setItem(refreshSlot, refreshItem);
         }
      }

      if (items.containsKey("your-orders")) {
         Map<?, ?> yourOrdersConfig = (Map)items.get("your-orders");
         if (yourOrdersConfig != null) {
            int yourOrdersSlot = this.getIntFromObject(yourOrdersConfig.get("slot"), 51);
            ItemStack yourOrdersItem = this.createNavigationItem(yourOrdersConfig, "Your Orders");
            gui.setItem(yourOrdersSlot, yourOrdersItem);
         }
      }

      if (items.containsKey("sort")) {
         Map<?, ?> sortConfig = (Map)items.get("sort");
         if (sortConfig != null) {
            int sortSlot = this.getIntFromObject(sortConfig.get("slot"), 47);
            String currentSort = (String)this.orderViewSortMode.get(playerId);
            ItemStack sortItem = this.createSortFilterItem(sortConfig, "Sort", currentSort);
            gui.setItem(sortSlot, sortItem);
         }
      }

      if (items.containsKey("filter")) {
         Map<?, ?> filterConfig = (Map)items.get("filter");
         if (filterConfig != null) {
            int filterSlot = this.getIntFromObject(filterConfig.get("slot"), 48);
            String currentFilter = (String)this.orderViewFilterMode.get(playerId);
            ItemStack filterItem = this.createSortFilterItem(filterConfig, "Filter", currentFilter);
            gui.setItem(filterSlot, filterItem);
         }
      }

      if (items.containsKey("search")) {
         Map<?, ?> searchConfig = (Map)items.get("search");
         if (searchConfig != null) {
            int searchSlot = this.getIntFromObject(searchConfig.get("slot"), 50);
            ItemStack searchItem = this.createNavigationItem(searchConfig, "Search");
            gui.setItem(searchSlot, searchItem);
         }
      }

   }

   public void handleOrderViewClick(InventoryClickEvent event, Player player) {
      UUID playerId = player.getUniqueId();
      int currentPage = (Integer)this.orderViewCurrentPage.getOrDefault(playerId, 1);
      int slot = event.getSlot();
      Map<String, Object> items = this.orderManager.getOrderViewItems();
      if (slot >= 0 && slot < 45) {
         int calculatedIndex = (currentPage - 1) * 45 + slot;
         OrderItem clickedOrder = this.getOrderItemAtSlot(player, currentPage, slot);
         if (clickedOrder != null) {
         }

         if (clickedOrder != null) {
            this.plugin.getSoundManager().playSound(player, "gui-click");
            if (player.getUniqueId().equals(clickedOrder.getCreator())) {
               if (this.plugin.getEditOrderGUI() != null) {
                  this.plugin.getEditOrderGUI().openEditOrderGUI(player, clickedOrder);
               }
            } else if (this.plugin.getDeliveryGUI() != null) {
               this.plugin.getDeliveryGUI().openOrderDelivery(player, clickedOrder);
            } else {
               this.plugin.getLangManager().sendMessage(player, "error");
               this.plugin.getSoundManager().playSound(player, "error");
            }
         }
      } else if (items != null && !items.isEmpty()) {
         if (items.containsKey("sort")) {
            Map<?, ?> sortConfig = (Map)items.get("sort");
            if (sortConfig != null && slot == this.getIntFromObject(sortConfig.get("slot"), 47)) {
               if (sortConfig.containsKey("keys")) {
                  List<?> keys = (List)sortConfig.get("keys");
                  if (keys != null && !keys.isEmpty()) {
                     this.plugin.getSoundManager().playSound(player, "gui-click");
                     String currentSort = (String)this.orderViewSortMode.get(playerId);
                     int nextIndex = 0;
                     if (currentSort != null) {
                        for(int i = 0; i < keys.size(); ++i) {
                           if (keys.get(i).toString().equals(currentSort)) {
                              nextIndex = (i + 1) % keys.size();
                              break;
                           }
                        }
                     }

                     String newSort = keys.get(nextIndex).toString();
                     this.orderViewSortMode.put(playerId, newSort);
                     String currentSearch = (String)this.orderViewSearchQuery.get(playerId);
                     this.openOrderGUI(player, 1, currentSearch);
                  }
               }

               return;
            }
         }

         if (items.containsKey("filter")) {
            Map<?, ?> filterConfig = (Map)items.get("filter");
            if (filterConfig != null && slot == this.getIntFromObject(filterConfig.get("slot"), 48)) {
               if (filterConfig.containsKey("keys")) {
                  List<?> keys = (List)filterConfig.get("keys");
                  if (keys != null && !keys.isEmpty()) {
                     this.plugin.getSoundManager().playSound(player, "gui-click");
                     String currentFilter = (String)this.orderViewFilterMode.get(playerId);
                     int nextIndex = 0;
                     if (currentFilter != null) {
                        for(int ix = 0; ix < keys.size(); ++ix) {
                           if (keys.get(ix).toString().equals(currentFilter)) {
                              nextIndex = (ix + 1) % keys.size();
                              break;
                           }
                        }
                     }

                     String newFilter = keys.get(nextIndex).toString();
                     this.orderViewFilterMode.put(playerId, newFilter);
                     String currentSearch = (String)this.orderViewSearchQuery.get(playerId);
                     this.openOrderGUI(player, 1, currentSearch);
                  }
               }

               return;
            }
         }

         if (items.containsKey("search")) {
            Map<?, ?> searchConfig = (Map)items.get("search");
            if (searchConfig != null && slot == this.getIntFromObject(searchConfig.get("slot"), 50)) {
               this.plugin.getSoundManager().playSound(player, "gui-click");
               player.closeInventory();
               Map<String, String> placeholders = new HashMap();
               placeholders.put("%type%", "search");
               this.plugin.getLangManager().sendMessage(player, "chat-input", placeholders);
               this.orderViewSearchMode.put(playerId, true);
               return;
            }
         }

         if (items.containsKey("previous-page") && slot == this.getIntFromObject(items.get("previous-page-slot"), 45)) {
            if (currentPage > 1) {
               this.plugin.getSoundManager().playSound(player, "back-page");
               String currentSearch = (String)this.orderViewSearchQuery.get(playerId);
               this.openOrderGUI(player, currentPage - 1, currentSearch);
            } else {
               this.plugin.getSoundManager().playSound(player, "error");
            }
         } else if (items.containsKey("next-page") && slot == this.getIntFromObject(items.get("next-page-slot"), 53)) {
            String currentSearch = (String)this.orderViewSearchQuery.get(playerId);
            List<OrderItem> allOrders = this.orderManager.getOrderItems();
            List<OrderItem> activeOrders = (List)allOrders.stream().filter((order) -> {
               if (!order.isActive()) {
                  return false;
               } else {
                  return order.isExpired() ? false : order.getRemainingAmount() > 0;
               }
            }).collect(Collectors.toList());
            List<OrderItem> filteredOrders = activeOrders;
            if (currentSearch != null && !currentSearch.isEmpty()) {
               String searchLower = currentSearch.toLowerCase();
               filteredOrders = (List)activeOrders.stream().filter((order) -> order.getName().toLowerCase().contains(searchLower) || order.getMaterial().name().toLowerCase().contains(searchLower)).collect(Collectors.toList());
            }

            String currentFilter = (String)this.orderViewFilterMode.get(playerId);
            if (currentFilter != null && !currentFilter.equals("all")) {
               filteredOrders = (List)filteredOrders.stream().filter((order) -> this.passesFilter(order, currentFilter)).collect(Collectors.toList());
            }

            int itemsPerPage = 45;
            int totalPages = (int)Math.ceil((double)filteredOrders.size() / (double)itemsPerPage);
            if (totalPages == 0) {
               totalPages = 1;
            }

            if (currentPage < totalPages) {
               this.plugin.getSoundManager().playSound(player, "next-page");
               this.openOrderGUI(player, currentPage + 1, currentSearch);
            } else {
               this.plugin.getSoundManager().playSound(player, "error");
            }
         } else {
            if (items.containsKey("refresh")) {
               Map<?, ?> refreshConfig = (Map)items.get("refresh");
               if (refreshConfig != null && slot == this.getIntFromObject(refreshConfig.get("slot"), 49)) {
                  this.plugin.getSoundManager().playSound(player, "refresh-gui");
                  String currentSearchx = (String)this.orderViewSearchQuery.get(playerId);
                  this.openOrderGUI(player, 1, currentSearchx);
                  return;
               }
            }

            if (items.containsKey("your-orders")) {
               Map<?, ?> yourOrdersConfig = (Map)items.get("your-orders");
               if (yourOrdersConfig != null && slot == this.getIntFromObject(yourOrdersConfig.get("slot"), 51)) {
                  this.plugin.getSoundManager().playSound(player, "gui-click");
                  this.orderGUI.openYourOrdersGUI(player);
                  return;
               }
            }
         }
      }

   }

   private OrderItem getOrderItemAtSlot(Player player, int currentPage, int slot) {
      UUID playerId = player.getUniqueId();
      String currentSearch = (String)this.orderViewSearchQuery.get(playerId);
      String currentFilter = (String)this.orderViewFilterMode.get(playerId);
      List<OrderItem> allOrders = this.orderManager.getOrderItems();
      List<OrderItem> activeOrders = (List)allOrders.stream().filter((order) -> {
         if (!order.isActive()) {
            return false;
         } else {
            return order.isExpired() ? false : order.getRemainingAmount() > 0;
         }
      }).collect(Collectors.toList());
      List<OrderItem> filteredOrders = activeOrders;
      if (currentSearch != null && !currentSearch.isEmpty()) {
         String searchLower = currentSearch.toLowerCase();
         filteredOrders = (List)activeOrders.stream().filter((order) -> order.getName().toLowerCase().contains(searchLower) || order.getMaterial().name().toLowerCase().contains(searchLower) || order.isSpecialItem() && order.getSubType() != null && order.getSubType().toLowerCase().contains(searchLower)).collect(Collectors.toList());
      }

      if (currentFilter != null && !currentFilter.equals("all")) {
         filteredOrders = (List)filteredOrders.stream().filter((order) -> this.passesFilter(order, currentFilter)).collect(Collectors.toList());
      }

      String currentSort = (String)this.orderViewSortMode.get(playerId);
      if (currentSort != null) {
         switch (currentSort) {
            case "most_money" -> filteredOrders.sort((a, b) -> Double.compare(b.getPricePerItem() * (double)b.getRequestedAmount(), a.getPricePerItem() * (double)a.getRequestedAmount()));
            case "most_delivered" -> filteredOrders.sort((a, b) -> Integer.compare(b.getDeliveredAmount(), a.getDeliveredAmount()));
            case "most_recent" -> filteredOrders.sort((a, b) -> b.getCreationDate().compareTo(a.getCreationDate()));
            case "most_paid_per_item" -> filteredOrders.sort((a, b) -> Double.compare(b.getPricePerItem(), a.getPricePerItem()));
            default -> filteredOrders.sort((a, b) -> a.getName().compareToIgnoreCase(b.getName()));
         }
      }

      int itemsPerPage = 45;
      int index = (currentPage - 1) * itemsPerPage + slot;

      for(int i = 0; i < Math.min(5, filteredOrders.size()); ++i) {
      }

      return index >= 0 && index < filteredOrders.size() ? (OrderItem)filteredOrders.get(index) : null;
   }

   private boolean passesFilter(OrderItem order, String filter) {
      Material material = order.getMaterial();
      switch (filter) {
         case "blocks" -> {
            return this.BLOCK_MATERIALS.contains(material) || material.name().endsWith("_BLOCK") || material.name().endsWith("_ORE") || material.name().contains("STONE");
         }
         case "tools" -> {
            return this.TOOL_MATERIALS.contains(material) || material.name().contains("PICKAXE") || material.name().contains("AXE") || material.name().contains("SHOVEL") || material.name().contains("HOE");
         }
         case "food" -> {
            return this.FOOD_MATERIALS.contains(material) || material.name().contains("COOKED") || material.name().endsWith("_STEW") || material == Material.APPLE || material == Material.BREAD;
         }
         case "combat" -> {
            return this.COMBAT_MATERIALS.contains(material) || material.name().contains("SWORD") || material.name().contains("HELMET") || material.name().contains("CHESTPLATE") || material.name().contains("LEGGINGS") || material.name().contains("BOOTS") || material == Material.BOW || material == Material.CROSSBOW || material == Material.TRIDENT || material == Material.SHIELD;
         }
         case "potions" -> {
            return this.POTION_MATERIALS.contains(material) || order.isSpecialItem() && "POTION".equals(order.getItemType()) || "TIPPED_ARROW".equals(order.getItemType());
         }
         case "books" -> {
            return this.BOOK_MATERIALS.contains(material) || order.isSpecialItem() && "ENCHANTED_BOOK".equals(order.getItemType());
         }
         case "ingredients" -> {
            return this.INGREDIENT_MATERIALS.contains(material) || material.name().endsWith("_INGOT") || material.name().endsWith("_DUST") || material.name().endsWith("_POWDER");
         }
         case "utilities" -> {
            return this.UTILITY_MATERIALS.contains(material) || material.name().endsWith("_CHEST") || material.name().endsWith("_FURNACE") || material.name().endsWith("_TABLE") || material.name().endsWith("_ANVIL");
         }
         default -> {
            return true;
         }
      }
   }

   private ItemStack createSortFilterItem(Map<?, ?> config, String defaultName, String currentValue) {
      Material material = Material.HOPPER;
      String displayName = defaultName;
      List<String> lore = new ArrayList();
      if (config.containsKey("material")) {
         try {
            String materialName = config.get("material").toString().toUpperCase();
            Material tmp = Material.valueOf(materialName);
            if (tmp != null && tmp.isItem()) {
               material = tmp;
            }
         } catch (IllegalArgumentException var14) {
         }
      }

      if (config.containsKey("name")) {
         displayName = config.get("name").toString();
      }

      if (config.containsKey("options") && config.containsKey("keys")) {
         List<?> options = (List)config.get("options");
         List<?> keys = (List)config.get("keys");
         String activePrefix = config.containsKey("active_prefix") ? config.get("active_prefix").toString() : "&#00fc88● ";
         String inactivePrefix = config.containsKey("inactive_prefix") ? config.get("inactive_prefix").toString() : "&f● ";

         for(int i = 0; i < options.size() && i < keys.size(); ++i) {
            String option = options.get(i).toString();
            String key = keys.get(i).toString();
            if (key.equals(currentValue)) {
               lore.add(ColorUtil.color(activePrefix + option));
            } else {
               lore.add(ColorUtil.color(inactivePrefix + option));
            }
         }
      }

      ItemStack item = new ItemStack(material);
      ItemMeta meta = item.getItemMeta();
      if (meta != null) {
         meta.setDisplayName(ColorUtil.color(displayName));
         if (!lore.isEmpty()) {
            meta.setLore(lore);
         }

         item.setItemMeta(meta);
      }

      return item;
   }

   private ItemStack createNavigationItem(Map<?, ?> config, String defaultName) {
      return this.createNavigationItemWithPlaceholders(config, defaultName, Collections.emptyMap());
   }

   private ItemStack createNavigationItemWithPlaceholders(Map<?, ?> config, String defaultName, Map<String, String> placeholders) {
      Material material = Material.ARROW;
      String displayName = defaultName;
      List<String> lore = new ArrayList();
      if (config.containsKey("material")) {
         try {
            String materialName = config.get("material").toString().toUpperCase();
            Material tmp = Material.valueOf(materialName);
            if (tmp != null && tmp.isItem()) {
               material = tmp;
            }
         } catch (IllegalArgumentException var12) {
         }
      }

      if (config.containsKey("displayname")) {
         displayName = config.get("displayname").toString();
      } else if (config.containsKey("name")) {
         displayName = config.get("name").toString();
      }

      if (config.containsKey("lore")) {
         Object loreObj = config.get("lore");
         if (loreObj instanceof List) {
            for(Object line : (List)loreObj) {
               lore.add(line.toString());
            }
         }
      }

      for(Map.Entry<String, String> entry : placeholders.entrySet()) {
         displayName = displayName.replace((CharSequence)entry.getKey(), (CharSequence)entry.getValue());
         List<String> newLore = new ArrayList();

         for(String line : lore) {
            newLore.add(line.replace((CharSequence)entry.getKey(), (CharSequence)entry.getValue()));
         }

         lore = newLore;
      }

      ItemStack item = new ItemStack(material);
      ItemMeta meta = item.getItemMeta();
      if (meta != null) {
         meta.setDisplayName(ColorUtil.color(displayName));
         if (!lore.isEmpty()) {
            List<String> coloredLore = new ArrayList();

            for(String line : lore) {
               coloredLore.add(ColorUtil.color(line));
            }

            meta.setLore(coloredLore);
         }

         item.setItemMeta(meta);
      }

      return item;
   }

   private int getIntFromObject(Object obj, int defaultValue) {
      if (obj instanceof Integer) {
         return (Integer)obj;
      } else if (obj instanceof String) {
         try {
            return Integer.parseInt((String)obj);
         } catch (NumberFormatException var4) {
            return defaultValue;
         }
      } else {
         return defaultValue;
      }
   }

   @EventHandler
   public void onPlayerChat(AsyncPlayerChatEvent event) {
      Player player = event.getPlayer();
      UUID playerId = player.getUniqueId();
      if ((Boolean)this.orderViewSearchMode.getOrDefault(playerId, false)) {
         event.setCancelled(true);
         String message = event.getMessage();
         if (message.equalsIgnoreCase("cancel")) {
            this.orderViewSearchMode.remove(playerId);
            this.orderViewSearchQuery.remove(playerId);
            this.plugin.getLangManager().sendMessage(player, "chat-input-cancel");
            this.plugin.getSoundManager().playSound(player, "error");
            if (this.plugin.isFolia()) {
               player.getScheduler().run(this.plugin, (task) -> this.openOrderGUI(player, 1, (String)null), (Runnable)null);
            } else {
               Bukkit.getScheduler().runTask(this.plugin, () -> this.openOrderGUI(player, 1, (String)null));
            }
         } else {
            String search = message.trim();
            this.orderViewSearchMode.remove(playerId);
            this.orderViewSearchQuery.put(playerId, search);
            Map<String, String> placeholders = new HashMap();
            placeholders.put("%search%", search);
            this.plugin.getSoundManager().playSound(player, "gui-click");
            if (this.plugin.isFolia()) {
               player.getScheduler().run(this.plugin, (task) -> this.openOrderGUI(player, 1, search), (Runnable)null);
            } else {
               Bukkit.getScheduler().runTask(this.plugin, () -> this.openOrderGUI(player, 1, search));
            }
         }
      }

   }

   public Map<UUID, String> getSearchQuery() {
      return this.orderViewSearchQuery;
   }

   public Map<UUID, Boolean> getSearchMode() {
      return this.orderViewSearchMode;
   }

   public Set<UUID> getIgnoreCloseEvents() {
      return this.orderViewIgnoreCloseEvents;
   }

   public Map<UUID, Integer> getCurrentPage() {
      return this.orderViewCurrentPage;
   }
}
